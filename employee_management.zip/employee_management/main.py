from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from employee_database import Root, Employee


# Connect to Database and create database session
engine = create_engine('sqlite:///employee.db?check_same_thread=False')
Root.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()


# landing page that will display all the students in our database
# This function will operate on the Read operation.
@app.route("/", methods=["GET"])
def main():
    if session.get == " username ":
        return render_template("home.html", session=session)
    else:
        return render_template('login.html')


@app.route('/login', methods= ['GET','POST'])
def login():

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username.lower() == "admin" and password == "admin":
            session["username"] = "admin"
            return render_template("home.html")
        else:
            msg = "Incorrect username or password"
            return render_template('login.html', msg=msg)
    else:
        return render_template('login.html', )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('home'))


@app.route('/')
@app.route('/records', methods= ['GET','POST'])
def showEmployee():
    records = session.query(Employee).all()
    return render_template('home.html', records=records)


# This will let us Create a new record and save it in our database
@app.route('/records/new/', methods=['GET', 'POST'])
def newEmployee():
    if request.method == 'POST':
        newEmployee = Employee(first_name=request.form['name'],
                       last_name=request.form['last_name'],
                       dob=request.form['dob'],
                       email=request.form['email'],
                       contact = request.form['contact'])
        session.add(newEmployee)
        session.commit()
        return redirect(url_for('showEmployee'))
    else:
        return render_template('newEmployee.html')


# This will let us Update our records and save it in our database
@app.route("/records/<int:emp_id>/edit/", methods=['GET', 'POST'])
def editEmployee(emp_id):
    editedEmployee = session.query(Employee).filter_by(id=emp_id).one()
    if request.method == 'POST':
        if request.form['email']:
            editedEmployee.fname = request.form['name']
            editedEmployee.lname = request.form['last_name']
            editedEmployee.dob = request.form['dob']
            editedEmployee.email = request.form['email']
            editedEmployee.contact = request.form['contact']

            return redirect(url_for('showEmployee'))
    else:
        return render_template('editEmployee.html', emp=editedEmployee)


# This will let us Delete our record
@app.route('/records/<int:emp_id>/delete/', methods=['GET', 'POST'])
def deleteEmployee(emp_id):
    employeeToDelete = session.query(Employee).filter_by(id=emp_id).one()
    if request.method == 'POST':
        session.delete(employeeToDelete)
        session.commit()
        return redirect(url_for('showEmployee', emp_id=emp_id))
    else:
        return render_template('deleteEmployee.html', emp=employeeToDelete)


"""
api functions
"""
from flask import jsonify


def get_records():
    records = session.query(Employee).all()
    return jsonify(records=[b.serialize for b in records])


def get_record(emp_id):
    records = session.query(Employee).filter_by(id=emp_id).one()
    return jsonify(records=records.serialize)


def makeANewRecord(first_name, last_name, dob, email):
    addedemployee = Employee(first_name=first_name, last_name=last_name, dob=dob, email=email)
    session.add(addedemployee)
    session.commit()
    return jsonify(Student=addedemployee.serialize)


def updateRecord(id, first_name, last_name, dob, email):
    updatedEmployee = session.query(Employee).filter_by(id=id).one()
    if not first_name:
        updatedEmployee.first_name = first_name
    if not last_name:
        updatedEmployee.last_name = last_name
    if not dob:
        updatedEmployee.dob = dob
    if not email:
        updatedEmployee.email = email
    session.add(updatedEmployee)
    session.commit()
    return 'Updated a Record with id %s' % id


def deleteARecord(id):
    EmployeeToDelete = session.query(Employee).filter_by(id=id).one()
    session.delete(EmployeeToDelete)
    session.commit()
    return 'Removed Record with id %s' % id


@app.route('/')
@app.route('/recordsApi', methods=['GET', 'POST'])
def recordsFunction():
    if request.method == 'GET':
        return get_records()
    elif request.method == 'POST':
        first_name = request.args.get('first_name', '')
        last_name = request.args.get('last_name', '')
        dob = request.args.get('dob', '')
        email = request.args.get('email', '')
        return makeANewRecord(first_name, last_name, dob, email)


@app.route('/recordsApi/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def recordFunctionId(id):
    if request.method == 'GET':
        return get_record(id)

    elif request.method == 'PUT':
        first_name = request.args.get('first_name', '')
        last_name = request.args.get('last_name', '')
        dob = request.args.get('dob', '')
        email = request.args.get('email', '')
        return updateRecord(id, first_name, last_name, dob, email)

    elif request.method == 'DELETE':
        return deleteARecord(id)


if __name__ == '__main__':
    app.run(debug=True)